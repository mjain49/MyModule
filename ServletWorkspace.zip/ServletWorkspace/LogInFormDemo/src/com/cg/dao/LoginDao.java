package com.cg.dao;

import com.cg.bean.Login;

public interface LoginDao {

	public Login LoginUser(Login user);
	
}
