package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.txw2.Document;

/**
 * Servlet implementation class CalculatorServlet
 */
@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculatorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String qstr=request.getParameter("action");
		if("index".equals(qstr))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("start.html");
			//RequestDispatcher is used to forward the request not redirect
			dispatch.forward(request, response);
					
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String qstr=request.getParameter("action");
		PrintWriter out=response.getWriter();
		if("start".equals(qstr))
		{
		String calc=request.getParameter("calc");
		if("add".equals(calc))
		{
			String num1= request.getParameter("num1");
			String num2 = request.getParameter("num2");
			//String res= request.getParameter("res");
			int res=Integer.parseInt(num1)+Integer.parseInt(num2);
			out.println("<html><form><table><tr> <td>Result</td> <td><input type=number name=res value=res/></td></tr></table></form></html>");
			// System.out.println(res);
			//request.setAttribute(res, res1);
			//document.getElementByName("res").innerHtml=res1;
		}
		else if("sub".equals(calc))
		{
			String num1= request.getParameter("num1");
			String num2 = request.getParameter("num2");
			int res=Integer.parseInt(num1)-Integer.parseInt(num2);
			// out.println(res);
			out.println("<html><form><table><tr> <td>Result</td> <td><input type=number name=res value=res/></td></tr></table></form></html>");
		}
		else if("mul".equals(calc))
		{
			String num1= request.getParameter("num1");
			String num2 = request.getParameter("num2");
			int res=Integer.parseInt(num1)*Integer.parseInt(num2);
			//out.println(res);
			out.println("<html><form><table><tr> <td>Result</td> <td><input type=number name=res value=res/></td></tr></table></form></html>");
		}
		else if("div".equals(calc))
		{
			String num1= request.getParameter("num1");
			String num2 = request.getParameter("num2");
			int res=Integer.parseInt(num1)/Integer.parseInt(num2);
			//out.println(res);
			out.println("<html><form><table><tr> <td>Result</td> <td><input type=number name=res value=res/></td></tr></table></form></html>");
		}
		else
			out.println("Input Invalid");
		}
		else
			response.sendError(404);
	}

}
