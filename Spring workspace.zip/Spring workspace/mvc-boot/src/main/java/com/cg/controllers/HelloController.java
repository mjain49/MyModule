package com.cg.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;

@RestController
public class HelloController {

	@GetMapping("/")
	public String hello() {
		return "Hello World";
	}
	
	@GetMapping("/products")
	public List <Product> getProducts(){
		List<Product> list = new LinkedList<Product>();
		list.add(new Product(101,"Windows 10 PRO","64 Bit OS for Desktop & Laptops",8000D));
		list.add(new Product(102,"Windows 9 PRO","64 Bit OS for Desktop & Laptops",7000D));
		list.add(new Product(101,"Windows 8 PRO","64 Bit OS for Desktop & Laptops",6000D));
		return list;
	}
}
