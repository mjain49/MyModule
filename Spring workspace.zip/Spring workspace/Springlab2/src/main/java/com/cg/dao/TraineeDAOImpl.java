package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.entities.Trainee;

public class TraineeDAOImpl implements TraineeDAO {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = emf.createEntityManager();
	
	public boolean add(Trainee trainee) {
		try {
			em.getTransaction().begin();
			em.persist(trainee); //add object into database
			em.getTransaction().commit();
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public boolean delete(Trainee trainee) {
		try {
			em.getTransaction().begin();
			em.remove(trainee);  //remove the object from database
			em.getTransaction().commit();
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public Trainee find(Integer id) {
		return em.find(Trainee.class, id);// find the full object from Trainee Class based on the id provided
	}

	public List<Trainee> getAll() {
		Query query=em.createNamedQuery("getall",Trainee.class); //here we used create named query because the query is already created in the Trainee.class , 
		//Here we just have to specify the name and the class Name
		List<Trainee> list = query.getResultList();
		return list;
	}

	public Trainee update(Trainee trainee) {
		try
		{
			em.getTransaction().begin();
			Trainee temp=em.find(Trainee.class, trainee.getId());
			temp.setName(trainee.getName());  //update the name
			temp.setDomain(trainee.getDomain());  //update the domain
 			temp.setLocation(trainee.getLocation());  // update the Location
			em.getTransaction().commit();
			return trainee;  //update Successful
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;  //update Unsuccessful
		}
	}

}
