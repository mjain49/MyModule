package com.cg.service;

import java.util.List;

import com.cg.entities.Trainee;

public interface TraineeService {
	
	public boolean add(Trainee trainee);
	public boolean delete(Trainee trainee);
	public Trainee find(Integer id);
	public List<Trainee> getAll();
	public Trainee update(Trainee trainee);
	
}
