package com.cg.service;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.TraineeDAO;
import com.cg.dao.TraineeDAOImpl;
import com.cg.entities.Trainee;

public class TraineeServiceImpl implements TraineeService{

	TraineeDAO dao = new TraineeDAOImpl();
	
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean add(Trainee trainee) {
		try {
			return dao.add(trainee);
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean delete(Trainee trainee) {
		try {
			return dao.delete(trainee);
		} catch (Exception e) {
			return false;
		}
	}

	@Transactional(readOnly=true)
	public Trainee find(Integer id) {
		return dao.find(id);
	}

	@Transactional(readOnly=true)
	public List<Trainee> getAll() {
		try {
			return dao.getAll();
		} catch (Exception e) {
			return null;
		}
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public Trainee update(Trainee trainee) {
		return dao.update(trainee);
	}
	

}
