package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Trainee")
@NamedQueries({
	@NamedQuery(name="getall", query="SELECT e FROM Trainee e")
})
public class Trainee {

	@Id
	private Integer id; 
	@Column(length=30)
	private String name;
	@Column(length=30)
	private String domain;
	@Column(length=30)
	private String location;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public Trainee() {
		
	}
	
	
	
	public Trainee(Integer id, String name, String domain, String location) {
		super();
		this.id = id;
		this.name = name;
		this.domain = domain;
		this.location = location;
	}
	
	
	@Override
	public String toString() {
		return "Trainee [id=" + id + ", name=" + name + ", domain=" + domain + ", location=" + location + "]";
	}
	
	
	
}
