package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;


@Configuration  //replacement of spring.xml
public class AppConfig {

	@Bean //Define a BEAN
	        //Syntax : public <ClassName> <BeanID>() { ... }
	public EmployeeDAO dao(){
		return new EmployeeDAO();
	}

	@Bean
	public EmployeeService service(){
		EmployeeService service =new EmployeeService();
		service.setDao(dao());
		return service;
	}
}

