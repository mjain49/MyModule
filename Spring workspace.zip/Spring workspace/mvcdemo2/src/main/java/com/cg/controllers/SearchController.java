package com.cg.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SearchController {

	@RequestMapping(value="/search", method = RequestMethod.GET)
	public String search(Model model, @RequestParam("q") String query){
		System.out.println("Searching For "+query);
		model.addAttribute("msg","Product "+query
				+" is currently unavailable, please try later!");
		return "home";
	}
	
	@RequestMapping(value="/calculatesimplint", method = RequestMethod.GET)
	public String calculatesimplint(Model model, @RequestParam("p") String p,@RequestParam("r") String r,@RequestParam("t") String t){
		Double Interest = (Double.parseDouble(p)*Double.parseDouble(r)*Double.parseDouble(t)/100);
		System.out.println(Interest);
		model.addAttribute("msg1","Simple Interest="+Interest);
		return "home";
	}
	
	@RequestMapping(value="/calculatecompint", method = RequestMethod.GET)
	public String calculatecompint(Model model, @RequestParam("p") double p,@RequestParam("r") double r,@RequestParam("t") double t,@RequestParam("n") double n){
		Double Amount = p* Math.pow((1+(r/n)),(n*t));
		Double Interest = Amount - p ;
		System.out.println(Interest);
		model.addAttribute("msg2","Compound Interest="+Interest);
		return "home";
	}	
}
