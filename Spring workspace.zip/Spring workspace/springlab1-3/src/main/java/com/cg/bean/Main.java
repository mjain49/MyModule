package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		// Get Bean of Type Employee AND ID emp
		Employee emp = context.getBean("emp", Employee.class);
		
		System.out.println("Employee Details");
		System.out.println("----------------------------------");
		System.out.println(emp);
		
	}

}
