package com.cg.iocdemo1;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main2 {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
			// Get Bean of Type Employee AND ID emp
			Employee emp = context.getBean("emp", Employee.class);
			// Get Bean with ID emp, but DON'T assign Type
			Employee emp2 = (Employee) context.getBean("emp");
			
			System.out.println();

	}
}
