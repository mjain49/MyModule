package com.cg.controller;

import org.springframework.web.bind.annotation.PostMapping;

import com.cg.dao.ProductDAOImpl;
import com.cg.entities.Product;

public class ApplicationController {

	ProductDAOImpl dao = new ProductDAOImpl();
	
	
	public Object getAll() {
		return dao.getAll();
	}

	@PostMapping("/add")
	public String addProduct(Product product) {
	
		if(dao.add(product)) {
			return "Product Added Successfully";
		}
		else
			return "Product Not Added Successfully";
	}

}
