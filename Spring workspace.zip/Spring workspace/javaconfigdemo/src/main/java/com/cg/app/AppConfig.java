package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDAO;
import com.cg.demo.EmployeeService;


@Configuration // This is REPLACEMENT of SPRING.XML
@ComponentScan("com.cg.demo")
public class AppConfig {
    //No Bean Definition needed!
}