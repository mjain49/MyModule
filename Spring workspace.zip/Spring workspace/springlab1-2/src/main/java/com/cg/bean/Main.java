package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		SBU sbu = context.getBean("sbu",SBU.class);
		// Get Bean of Type Employee AND ID emp
		//Employee emp = context.getBean("emp", Employee.class);
		
		System.out.println("SBU Details");
		System.out.println("----------------------------------");
		System.out.println(sbu);
		
	}

}
