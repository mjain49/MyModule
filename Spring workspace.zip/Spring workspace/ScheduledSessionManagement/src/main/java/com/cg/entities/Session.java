package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Session2")
public class Session {
	@Id
	private Integer id;
	
	@Column(name="name",length=20)
	private String name;//Session Name
	
	@Column(name="duration",length=15)
	private Integer duration;//Duration of corresponding session
	
	@Column(name="faculty",length=30)
	private String faculty;//faculty name
	
	@Column(name="mode2",length=10)
	private String mode;//Mode i.e. either ILT or VC

	public Session(Integer id, String name, Integer duration, String faculty, String mode) {
		super();
		this.id = id;
		this.name = name;
		this.duration = duration;
		this.faculty = faculty;
		this.mode = mode;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	@Override
	public String toString() {
		return "Session [id=" + id + ", name=" + name + ", duration=" + duration + ", faculty=" + faculty + ", mode="
				+ mode + "]";
	}
	
	
	

}
