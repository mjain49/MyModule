package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.services.SessionServiceImpl;

@RestController
public class SessionController {

	@Autowired
	private SessionServiceImpl service;

	@PostMapping(value = "/create", consumes = { "application/json" })
	public ResponseEntity<String> add(@RequestBody com.cg.entities.Session p) {
		service.add(p);
		return new ResponseEntity<String>("Record Successfully Added:",HttpStatus.OK);
	}

	@PutMapping(value = "/update", consumes = { "application/json" })
	public ResponseEntity<String> update(@RequestBody com.cg.entities.Session s) {
		service.update(s);
		return new ResponseEntity<String>("Record Successfully Updated:",HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete-{id}")
	public ResponseEntity<String> delete(@PathVariable int id) {
		service.delete(id);
		return new ResponseEntity<String>("Record Successfully Deleted:",HttpStatus.OK);
	}

	@GetMapping(value = "/view", produces = { "application/json" })
	public List<com.cg.entities.Session> viewAll() {
		return service.viewAll();
	}

}
