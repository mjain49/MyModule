package com.cg.services;

import java.util.List;
import com.cg.entities.Session;

public interface SessionService {
	
	public void add(Session p);     //Add
	public void update(Session q);  //Update  Duration and faculty Name based on session Id
	public List<Session> viewAll(); //View All Session Details
	public void delete(int id);  //Delete session details based on Session Id	
}
 