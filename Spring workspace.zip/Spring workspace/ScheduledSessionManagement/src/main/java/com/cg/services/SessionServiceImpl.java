package com.cg.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.daos.SessionDAO;
import com.cg.entities.Session;
import com.cg.exceptions.ApplicationException;
import com.cg.services.SessionService;

@Service
@Transactional
public class SessionServiceImpl implements SessionService {
	
	@Autowired private SessionDAO dao;

	@Transactional(propagation=Propagation.REQUIRED)
	public void add(Session p) {
	if(dao.existsById(p.getId())) {
	throw new RuntimeException("Session Already Exists!!");
	}
	dao.save(p);
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void update(Session q) {
		Optional<Session> s1= dao.findById(q.getId());	
		if(s1.isPresent())
		{
			Session t=s1.get();
			t.setDuration(q.getDuration());
			t.setFaculty(q.getFaculty());
		}
		else
			throw new RuntimeException("Session not Found!!");
	}

	@Transactional(readOnly=true)
	public List<Session> viewAll() {
		return dao.findAll();
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void delete(int id) {
		Optional<Session> s1= dao.findById(id);
		if(s1.isPresent()) {
		dao.deleteById(id);
		}
		else
			throw new ApplicationException("Session Id does not exists!");
	}
	
}
