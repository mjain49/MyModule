export class Product{
    id:number;
    name:String;
    price:number;
}
