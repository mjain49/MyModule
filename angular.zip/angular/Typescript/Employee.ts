export class IEmployee{
   //if we want to use IEmployee in other class
    empId:number;
    empName:String;
    empSalary:number;
    empStatus:boolean;
}