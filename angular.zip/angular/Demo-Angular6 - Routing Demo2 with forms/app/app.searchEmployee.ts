import { Component } from "@angular/core";
import { EmployeeService } from "./app.employeeservice";
import { Router } from "@angular/router";

@Component({
    selector:'search-com',
    templateUrl:'searchEmployee.html'
})

export class SearchEmployeeComponent{
 
}
