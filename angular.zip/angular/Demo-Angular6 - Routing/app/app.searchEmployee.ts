import { Component } from "@angular/core";

@Component({
    selector:'search-com',
    templateUrl:'searchEmployee.html'
})

export class SearchEmployeeComponent{
    
}
