package stepDefinition;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {

	@After
	public void after() {
		System.out.println("After Method");
		System.out.println("==============================================================================");
	}

	@Before
	public void before() {
		System.out.println("Before Method");
	}

	@Given("^User is is on Home Page$")
	public void user_is_is_on_Home_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^User enters \"([^\"]*)\"$")
	public void user_enters(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("UserName="+arg1);
	}

	@When("^User enters \"([^\"]*)\" to LogIn$")
	public void user_enters_to_LogIn(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Password="+arg1);
	}

	@Then("^print \"([^\"]*)\"$")
	public void print(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Result="+arg1);
	}

	@When("^User enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("UserName="+arg1);
	}

	@When("^User enters (\\d+) to LogIn$")
	public void user_enters_to_LogIn(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Password="+arg1);
	}

}
