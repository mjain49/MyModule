package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPageFactory {
	
	//Driver definition
	WebDriver driver;
	//Initiating the Driver
	public RegisterPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//Step 1 : Identify Elements
	
	@FindBy(name="name")  //find by is to find element name specified in the form
	@CacheLookup   //to cache the value of that element of the form whose name is specified inside FindBy tag 
	WebElement name;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="marks")
	@CacheLookup
	WebElement marks;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement loginButton;
	
	@FindBy(xpath="//*[@id=\"nameErrMsg\"]")
	WebElement nameError;
	

	@FindBy(xpath="//*[@id=\"addressErrMsg\"]")
	WebElement addressError;
	

	@FindBy(xpath="//*[@id=\"markErrMsg\"]")
	WebElement marksError;

	
	//Step 2) Getters and Setters
	
	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getName() {
		return name;
	}

	//changes here
	public void setName(String name) { //here String
		this.name.sendKeys(name);   //here add sendkeys()
	}


	public WebElement getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address.sendKeys(address);
	}


	public WebElement getMarks() {
		return marks;
	}


	public void setMarks(String marks) {
		this.marks.sendKeys(marks);
	}


	public WebElement getNameError() {
		return nameError;
	}


	public void setNameError(WebElement nameError) {
		this.nameError = nameError;
	}


	public WebElement getAddressError() {
		return addressError;
	}


	public void setAddressError(WebElement addressError) {
		this.addressError = addressError;
	}


	public WebElement getMarksError() {
		return marksError;
	}


	public void setMarksError(WebElement marksError) {
		this.marksError = marksError;
	}



	public void setLoginButton() {
		this.loginButton.click();
	}
	
	
	
}
