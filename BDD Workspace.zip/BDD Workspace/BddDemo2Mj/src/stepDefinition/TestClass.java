package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User Searched for Lenovo Laptop$")
	public void user_Searched_for_Lenovo_Laptop() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Add the first laptop that appears in the search result yo basket$")
	public void add_the_first_laptop_that_appears_in_the_search_result_yo_basket() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User basket should display with (\\d+) item$")
	public void user_basket_should_display_with_item(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
