package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.DiscountPageFactory;

public class DiscountClass {

	private WebDriver driver;
	private DiscountPageFactory dpf;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		// driver=new FirefoxDriver();
	}

	@Given("^Admin is on 'Discount' page$")
	public void admin_is_on_Discount_page() throws Throwable {
		
		driver.get("D:\\BDD Workspace\\AddProduct\\target\\addDiscount.html");
		dpf = new DiscountPageFactory(driver);
		Thread.sleep(5000);
	}

	@When("^Admin leave Product Field Empty$")
	public void admin_leave_Product_Field_Empty() throws Throwable {
		dpf.setMproduct("");
		dpf.setMsbtn();
	}

	@Then("^displays message 'Please Select Products'$")
	public void displays_message_Please_Select_Products() throws Throwable {
		String expectedMessage="Please select Any Product";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Admin leave Discount Field Empty$")
	public void admin_leave_Discount_Field_Empty() throws Throwable {
		dpf.setMproduct("p1");
		dpf.setMdiscount("");
		dpf.setMsbtn();
	}

	@Then("^displays message 'Please fill the Discount'$")
	public void displays_message_Please_fill_the_Discount() throws Throwable {
		String expectedMessage="Please enter Discount %";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Admin leave Start Date Field Empty$")
	public void admin_leave_Start_Date_Field_Empty() throws Throwable {
		dpf.setMproduct("p1");
		dpf.setMdiscount("20");
		dpf.setMsdate("");
		dpf.setMsbtn();
	}

	@Then("^displays message 'Please select the Start Date'$")
	public void displays_message_Please_select_the_Start_Date() throws Throwable {
		String expectedMessage="Please enter Discount Starting Date";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Admin leave End Date Field Empty$")
	public void admin_leave_End_Date_Field_Empty() throws Throwable {
		dpf.setMproduct("p1");
		dpf.setMdiscount("20");
		dpf.setMsdate("08/21/2019");
		dpf.setMedate("");
		dpf.setMsbtn();
	}

	@Then("^displays message 'Please select the End Date'$")
	public void displays_message_Please_select_the_End_Date() throws Throwable {
		String expectedMessage="Please enter Discount Ending Date";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Admin click on Submit Button$")
	public void admin_click_on_Submit_Button() throws Throwable {
		dpf.setMproduct("p1");
		dpf.setMdiscount("20");
		dpf.setMsdate("08/21/2019");
		dpf.setMedate("08/30/2019");
		dpf.setMsbtn();
	}

	@Then("^displays message 'You submitted successfully!'$")
	public void displays_message_You_submitted_successfully() throws Throwable {
		String expectedMessage="Successfully Added";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		//driver.get("D:\\\\BDD Workspace\\\\AddProduct\\\\target\\abc.html");
		
	}

	@When("^Admin click on Reset Button$")
	public void admin_click_on_Reset_Button() throws Throwable {
	    dpf.setMrbtn();
	}

	@Then("^display 'admin' page$")
	public void display_admin_page() throws Throwable {
		driver.get("D:\\BDD Workspace\\AddProduct\\target\\addDiscount.html");
		driver.close();
	}
	
	@When("^Admin click on Back TO Discount Button$")
	public void admin_click_on_Back_TO_Discount_Button() throws Throwable {
		dpf.setMebtn();
	}

	@Then("^Navigate to show-discount page$")
	public void navigate_to_show_discount_page() throws Throwable {
		driver.get("D:\\\\BDD Workspace\\\\AddProduct\\\\target\\showDiscount.html");
	}
}