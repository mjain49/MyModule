package updateStepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.UpdatePageFactory;

public class UpdateClass {

	private WebDriver driver;
	private UpdatePageFactory upf;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		// driver=new FirefoxDriver();
	}

	
		@Given("^Admin is on 'Discount Update' page$")
		public void admin_is_on_Discount_Update_page() throws Throwable {
			driver.get("D:\\BDD Workspace\\AddProduct\\target\\updateDiscount.html");
			upf = new UpdatePageFactory(driver);
			//Thread.sleep(5000);
		}

		@When("^Admin leave Discount-Field Empty$")
		public void admin_leave_Discount_Field_Empty() throws Throwable {
		    upf.setMdiscount("");
		    upf.setMsbtn();
		}

		@Then("^displays message 'Please fill the Discount Field$")
		public void displays_message_Please_fill_the_Discount_Field() throws Throwable {
			String expectedMessage="Please enter Discount %";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			//Thread.sleep(5000);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin leave Start-Date Field Empty$")
		public void admin_leave_Start_Date_Field_Empty() throws Throwable {
			upf.setMdiscount("20");
			upf.setMsdate("");
			upf.setMsbtn();
		    
		}

		@Then("^displays message 'Please Fill the Start Date'$")
		public void displays_message_Please_Fill_the_Start_Date() throws Throwable {
			String expectedMessage="Please enter Discount Starting Date";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(5000);
			driver.switchTo().alert().accept();
			driver.close();
		    
		}

		@When("^Admin leave End-Date Field Empty$")
		public void admin_leave_End_Date_Field_Empty() throws Throwable {
		    
			upf.setMdiscount("20");
			upf.setMsdate("08/21/2019");
			upf.setMedate("");
			upf.setMsbtn();
		}

		@Then("^displays message 'Please Fill the End Date'$")
		public void displays_message_Please_Fill_the_End_Date() throws Throwable {
			String expectedMessage="Please enter Discount Ending Date";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(5000);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin click on update-Button$")
		public void admin_click_on_update_Button() throws Throwable {
			upf.setMdiscount("20");
			upf.setMsdate("08/21/2019");
			upf.setMedate("08/30/2019");
			upf.setMsbtn();
		}

		@Then("^displays message 'You updated successfully!'$")
		public void displays_message_You_updated_successfully() throws Throwable {
			String expectedMessage="Successfully Added";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(5000);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin click on back Button$")
		public void admin_click_on_back_Button() throws Throwable {
		    upf.setMrbtn();
		}

		@Then("^navigate to show-discount page$")
		public void navigate_to_show_discount_page() throws Throwable {
			driver.get("D:\\\\BDD Workspace\\\\AddProduct\\\\target\\showDiscount.html");
		}

}