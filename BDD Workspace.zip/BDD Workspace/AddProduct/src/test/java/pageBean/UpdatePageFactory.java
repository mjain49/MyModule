package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdatePageFactory {

	// Driver definition
	WebDriver driver;

	// Initiating the Driver
	public UpdatePageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Step 1 : Identify Elements
	
	@FindBy(name="discount")
	@CacheLookup
	WebElement mdiscount;
	
	@FindBy(name="sdate")
	@CacheLookup
	WebElement msdate;
	
	@FindBy(name="edate")
	@CacheLookup
	WebElement medate;
	
	@FindBy(id="sbtn")
	@CacheLookup
	WebElement msbtn;

	@FindBy(id="rbtn")
	@CacheLookup
	WebElement mrbtn;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getMdiscount() {
		return mdiscount;
	}

	public void setMdiscount(String mdiscount) {
		this.mdiscount.sendKeys(mdiscount);
	}

	public WebElement getMsdate() {
		return msdate;
	}

	public void setMsdate(String msdate) {
		this.msdate.sendKeys(msdate);
	}

	public WebElement getMedate() {
		return medate;
	}

	public void setMedate(String medate) {
		this.medate.sendKeys(medate);
	}

	public void setMsbtn() {
		this.msbtn.click();
	}

	public void setMrbtn() {
		this.mrbtn.click();
	}

	
}