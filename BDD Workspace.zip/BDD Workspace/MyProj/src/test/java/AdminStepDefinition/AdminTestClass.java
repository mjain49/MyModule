package AdminStepDefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pageBean.AdminPageFactory;
import pageBean.MerchantPageFactory;

public class AdminTestClass {

		private WebDriver driver;
		private AdminPageFactory apf;
	
		@Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver",
					"D:\\softwares\\chromedriver_win32\\chromedriver.exe" );
			driver= new ChromeDriver();
			//driver=new FirefoxDriver();
		}
		
		@Given("^Admin is on 'register' Page$")
		public void Admin_is_on_register_Page() throws Throwable {
			driver.get("D:\\BDD Workspace\\MyProj\\target\\Register.html");
			apf = new AdminPageFactory(driver);  
		}

		@When("^Admin Enters Invalid Category$")
		public void Admin_Enters_Invalid_Category() throws Throwable {
		    
			apf.setCategory("");
			apf.setRedirect();
		}

		@Then("^display 'Please Enter Valid Category'$")
		public void display_Please_Enter_Valid_Category() throws Throwable {
			
		}

		@When("^Admin Enters Valid Category and Category=\"([^\"]*)\"$")
		public void Admin_Enters_Valid_Category_and_Category(String arg1) throws Throwable {
		    
			apf.setCategory("Admin");
			apf.setRedirect();
		}

		@When("^Display 'admin' page$")
		public void display_admin_page() throws Throwable {
		    
			driver.get("D:\\BDD Workspace\\MyProj\\target\\Admin.html");
			apf = new AdminPageFactory(driver);
		}

		@Given("^Admin is on 'admin' Page$")
		public void Admin_is_on_admin_Page() throws Throwable {
		    
			driver.get("D:\\BDD Workspace\\MyProj\\target\\Admin.html");
			apf = new AdminPageFactory(driver);
		}

		@When("^Admin Enters Invalid First Name$")
		public void Admin_Enters_Invalid_First_Name() throws Throwable {
		    
			apf.setFname("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid First Name'$")
		public void display_Please_Enter_Valid_First_Name() throws Throwable {
			String expectedMessage="Please fill the First Name";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin Enters Invalid Last Name$")
		public void Admin_Enters_Invalid_Last_Name() throws Throwable {
		    
			apf.setFname("Mayur");
			apf.setLname("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid Last Name'$")
		public void display_Please_Enter_Valid_Last_Name() throws Throwable {
			String expectedMessage="Please fill the Last Name";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin Enters Invalid EmailID$")
		public void Admin_Enters_Invalid_EmailID() throws Throwable {
		    
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid EmailID'$")
		public void display_Please_Enter_Valid_EmailID() throws Throwable {
			String expectedMessage="Please fill the Email";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@Given("^Admin is on 'admin' page$")
		public void Admin_is_on_admin_page() throws Throwable {
		    
			driver.get("D:\\BDD Workspace\\MyProj\\target\\Admin.html");
			apf = new AdminPageFactory(driver);
		}

		@When("^Admin Enters Invalid Password$")
		public void Admin_Enters_Invalid_Password() throws Throwable {
		    
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("mayur.jain@capgemini.com");
			apf.setPassword("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid Password'$")
		public void display_Please_Enter_Valid_Password() throws Throwable {
			String expectedMessage="Please fill the Password";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		
		
		@When("^Admin Enters Invalid ConfirmPassword$")
		public void Admin_Enters_Invalid_ConfirmPassword() throws Throwable {
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("mayur.jain@capgemini.com");
			apf.setPassword("Admin@1234");
			apf.setConfirmpassword("");
		    apf.setConfirmButton();
		}
		
		@Then("^display 'Please Enter Valid ConfirmPassword'$")
		public void display_Please_Enter_Valid_ConfirmPassword() throws Throwable {
			String expectedMessage="Please fill the Confirm Password";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin Enters Invalid Answer for SecrityQuestion one$")
		public void Admin_Enters_Invalid_Answer_for_SecrityQuestion_one() throws Throwable {
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("mayur.jain@capgemini.com");
			apf.setPassword("Admin@1234");
			apf.setConfirmpassword("Admin@1234");
			apf.setFsq("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid Answer for SecrityQuestion one'$")
		public void display_Please_Enter_Valid_Answer_for_SecrityQuestion_one() throws Throwable {
			String expectedMessage="Please fill the answer for Security Question one";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close();
		}

		@When("^Admin Enters Invalid Answer for SecrityQuestion two$")
		public void Admin_Enters_Invalid_Answer_for_SecrityQuestion_two() throws Throwable {
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("mayur.jain@capgemini.com");
			apf.setPassword("Admin@1234");
			apf.setConfirmpassword("Admin@1234");
			apf.setFsq("Mumbai");
			apf.setSsq("");
		    apf.setConfirmButton();
		}

		@Then("^display 'Please Enter Valid Answer for SecrityQuestion two'$")
		public void display_Please_Enter_Valid_Answer_for_SecrityQuestion_two() throws Throwable {
			String expectedMessage="Please fill the answer for Security Question two";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.close(); 
		}

		@When("^Admin clicks on Create Account$")
		public void Admin_clicks_on_Create_Account() throws Throwable {
			apf.setFname("Mayur");
			apf.setLname("Jain");
			apf.setEmail("mayur.jain@capgemini.com");
			apf.setPassword("admin@1234");
			apf.setConfirmpassword("admin@1234");
			apf.setFsq("Mumbai");
			apf.setSsq("Ram");
		    apf.setConfirmButton();
		}

		@Then("^display 'success' Page$")
		public void display_success_Page() throws Throwable {
			String expectedMessage="Successfull!!!!!!";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			driver.switchTo().alert().accept();
			driver.get("D:\\BDD Workspace\\MyProj\\target\\success.html"); 
		}
}
