$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("showProduct.feature");
formatter.feature({
  "line": 1,
  "name": "Show Product",
  "description": "",
  "id": "show-product",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "User will add Product to Cart on Amazon",
  "description": "",
  "id": "show-product;user-will-add-product-to-cart-on-amazon",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "User will select Products",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "User will Add Products to Cart",
  "keyword": "And "
});
formatter.step({
  "line": 5,
  "name": "User clicks on show cart",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Show the list of products to user from cart",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});