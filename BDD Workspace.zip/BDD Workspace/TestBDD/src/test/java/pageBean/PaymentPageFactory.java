package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageFactory {

	//Driver
		WebDriver driver;
		
	//Initialization
	public PaymentPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		
//	@FindBy(xpath="/html/head/title")
//	@CacheLookup
//	WebElement title;
	
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement chname;	
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement debitnum;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	
	@FindBy(name="month")
	@CacheLookup
	WebElement month;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement year;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement btnPayment;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

//	
//	public WebElement getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title.sendKeys(title);
//	}

	public WebElement getChname() {
		return chname;
	}

	public void setChname(String chname) {
		this.chname.sendKeys(chname);
	}

	public WebElement getDebitnum() {
		return debitnum;
	}

	public void setDebitnum(String debitnum) {
		this.debitnum.sendKeys(debitnum);
	}

	
	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public WebElement getBtnPayment() {
		return btnPayment;
	}

	public void setBtnPayment() {
		this.btnPayment.click();
	}
	
	
	
}
